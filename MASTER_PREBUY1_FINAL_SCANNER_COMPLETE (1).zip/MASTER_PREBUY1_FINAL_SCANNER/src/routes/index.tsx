import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { runScan, type Row, type ScanResult } from "@/lib/scanner.functions";
import { FINAL_MULTIPLIER, FINAL_PERIOD } from "@/lib/strategy";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MASTER 선취매1번 스캐너" },
      {
        name: "description",
        content:
          "선취매1 Final 전용 스캐너. KOSPI/KOSDAQ 전종목에서 Final선 = Lowest(L,20) × 1.10 상향돌파를 계산합니다.",
      },
      { property: "og:title", content: "MASTER 선취매1번 스캐너" },
      {
        property: "og:description",
        content: "원본식 전용 · 임의 점수/등급/승률/임계값 없음.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function fmt(n: number, digits = 0) {
  return n.toLocaleString("ko-KR", { maximumFractionDigits: digits, minimumFractionDigits: digits });
}

function toCsv(rows: Row[]): string {
  const head = ["코드", "종목명", "시장", "기준일", "현재가", "발생근거", "Final선"];
  const body = rows.map((r) => [r.code, r.name, r.market, r.date, r.close, r.reason, r.finalLine].join(","));
  return "\uFEFF" + [head.join(","), ...body].join("\n");
}

function Index() {
  const scan = useServerFn(runScan);
  const autoRunRef = useRef(false);

  const [running, setRunning] = useState(false);
  const [status, setStatus] = useState("대기 중");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ScanResult | null>(null);

  useEffect(() => {
    if (!autoRunRef.current) {
      autoRunRef.current = true;
      run();
    }
  }, []);

  async function run() {
    if (running) return;
    setRunning(true);
    setError(null);
    setResult(null);
    setStatus("데이터 수집 및 계산 중…");
    try {
      const r = await scan({ data: undefined } as never);
      setResult(r);
      setStatus(r.rows.length > 0 ? "완료" : "정상 0건");
    } catch (e) {
      setResult(null);
      setStatus("실행중지");
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setRunning(false);
    }
  }

  function download() {
    if (!result) return;
    const blob = new Blob([toCsv(result.rows)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `선취매1번_${result.targetDate}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <main className="min-h-screen bg-background px-4 py-6 text-foreground">
      <div className="mx-auto w-full max-w-3xl">
        <header className="mb-5">
          <h1 className="text-xl font-bold tracking-tight">MASTER 선취매1번 스캐너</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            선취매1 Final 원본식 전용 · 임의 점수/등급/승률/임계값 없음
          </p>
          <p className="mt-2 text-xs font-mono text-muted-foreground">
            Final선 = Lowest(L,{FINAL_PERIOD}) × {FINAL_MULTIPLIER.toFixed(2)}
          </p>
          <p className="mt-1 text-xs font-mono text-muted-foreground">
            신호: 전일 종가 ≤ 전일 Final선 AND 당일 종가 &gt; 당일 Final선
          </p>
        </header>

        <button
          onClick={run}
          disabled={running}
          className="w-full rounded-xl bg-primary px-5 py-4 text-base font-bold text-primary-foreground disabled:opacity-50"
        >
          {running ? "스캔 중…" : "선취매1번 종목 뽑기"}
        </button>

        <div className="mt-4 rounded-xl border border-border bg-card p-4 text-sm">
          <span className={error ? "font-semibold text-destructive" : "text-muted-foreground"}>{status}</span>
          {error ? (
            <p className="mt-3 whitespace-pre-wrap rounded-lg bg-destructive/10 p-3 text-xs text-destructive">
              {error}
              {"\n"}부분 결과는 표시하지 않습니다 (FAIL-CLOSED).
            </p>
          ) : null}
        </div>

        {result ? (
          <div className="mt-4 grid grid-cols-2 gap-2 rounded-xl border border-border bg-card p-4 text-xs">
            <Info label="기준일" value={result.targetDate} />
            <Info label="데이터 모드" value={result.mode} />
            <Info label="실제 거래일(refDate)" value={result.refDate} />
            <Info label="아카이브 최신일" value={result.archiveLatest} />
            <Info label="과거 거래일 수" value={fmt(result.archiveDates)} />
            <Info label="종목 수" value={fmt(result.universe)} />
            <Info label="현재봉 수" value={fmt(result.liveCount)} />
            <Info label="제외" value={fmt(result.excluded)} />
            <Info label="150봉 미만 제외" value={fmt(result.skippedShort)} />
            <Info label="기준일 불일치 제외" value={fmt(result.skippedStale)} />
            <Info label="계산 종목 수" value={fmt(result.computed)} />
            <Info label="신호 종목 수" value={fmt(result.rows.length)} />
          </div>
        ) : null}

        {result && result.rows.length === 0 ? (
          <div className="mt-4 rounded-xl border border-border bg-card p-4 text-sm">
            <p className="font-semibold">정상 0건 — 원본식 최종신호가 발생한 종목이 없습니다.</p>
          </div>
        ) : null}

        {result && result.rows.length > 0 ? (
          <div className="mt-4 rounded-xl border border-border bg-card">
            <div className="flex justify-end p-3">
              <button onClick={download} className="rounded-lg border border-border px-3 py-1.5 text-xs">
                CSV 저장
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-xs">
                <thead className="bg-muted text-muted-foreground">
                  <tr>
                    <Th>종목</Th>
                    <Th>시장</Th>
                    <Th>기준일</Th>
                    <Th>현재가</Th>
                    <Th>발생근거</Th>
                    <Th>Final선</Th>
                    <Th>차트</Th>
                  </tr>
                </thead>
                <tbody>
                  {result.rows.map((r) => (
                    <tr key={r.code} className="border-t border-border">
                      <td className="px-3 py-2 font-semibold">
                        {r.name} <span className="text-muted-foreground tabular-nums">{r.code}</span>
                      </td>
                      <td className="px-3 py-2">{r.market}</td>
                      <td className="px-3 py-2 tabular-nums">{r.date}</td>
                      <td className="px-3 py-2 tabular-nums">{fmt(r.close)}</td>
                      <td className="px-3 py-2">{r.reason}</td>
                      <td className="px-3 py-2 tabular-nums">{fmt(r.finalLine, 2)}</td>
                      <td className="px-3 py-2">
                        <a
                          href={`https://finance.naver.com/item/main.naver?code=${r.code}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-primary underline underline-offset-2"
                        >
                          차트
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : null}
      </div>
    </main>
  );
}

function Th({ children }: { children: React.ReactNode }) {
  return <th className="whitespace-nowrap px-3 py-2 font-medium">{children}</th>;
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-muted-foreground">{label}</div>
      <div className="font-semibold">{value}</div>
    </div>
  );
}
